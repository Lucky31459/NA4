# import socket #UDP socket banana hai
# import sys 
import struct 
# import sys
# import time
# import threading 
# import os
# from collections import OrderedDict 


# SEQ_FMT = "!I"
# RESERVED = 16
# MAX_PAYLOAD = 1200
# MAX_DATA = MAX_PAYLOAD - RESERVED - SEQN_BITS
# DATA_FILE = "data.txt"

# ALPHA = 0.125
# BETA = 0.25
# K = 4
# INITIAL_RTO - 1.0

# def make_packet(seq_num: int, data: bytes) -> bytes:
#     header = struct.pack(SEQ_FMT, seq_num) + (b'\x00' * RESERVED )
#     return header + data

# def parse_ack_packet(pkt: bytes) -> int:
#     if len(pkt) < 4 :
#         return None
#     next_packet = struct.unpack(SEQ_FMT, pkt[0:4] )[0]
#     return nxt_exp

# def now():
#     return time.time()

# class UDP:
#     def __init__(self, ip, port, sws):
#         self.addr = (ip, int(port))
#         self.sws = int(sws)
#         self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#         self.sock.bind(self.addr)
#         self.client_addr = None
#         with open(DATA_FILE, "rb") as f:
#             self.file_bytes = f.read()
#         self.file_len = len(self.file_bytes)

#         self.segments = OrderedDict()
#         seq = 0 
#         while seq < self.file_len :
#             chunk = self.file_bytes[seq : seq + MAX_DATA]
#             self.segments[seq] = chunk
#             seq += len(chunk)
        
#         segment[self.file_len] = b'EOF'
        
#         self.base = 0 
#         self.next_seq = 0
#         self.lock = 

import socket 
import sys
import time 
import select
import os
import time
import select
from collections import OrderedDict


SEQ_FMT = "!1"
SEQ_SIZE = 4
RESERVED_SIZE = 16
MAX_UDP_PAYLOAD = 1200
MAX_DATA = MAX_UDP_PAYLOAD - SEQ_SIZE - RESERVED_SIZE

DATA_FILE = "data.txt"

ALPHA = 0.125
BETA = 0.25
K= 4
INITIAL_RTO = 1.0
MIN_RT0 = 0.1

DUP_ACK_THRESHOLD = 3

def make_packet():
    header = struct.pack(SEQ_FMT, seq_num) + (b'\x00' * RESERVED_SIZE)
    return header + data

def parse_ack(pkt: bytes):
    if len(pkt) < SEQ_SIZE :
        return None
    return struct.unpack(SEQ_FMT, pkt[:SEQ_SIZE])[0]

 def now():
    return time.time()

class UDP:
    def __init__(self, ip, port, sws_bytes ):
        self.addr = (ip, int(port))
        self.sws = int(sws_bytes)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(self.addr)
        self.sock.setblocking(False)

        with open(DATA_FILE, "rb") as f:
            self.file_bytes = f.read()
        
        self.file_len = len(self.self.file_bytes)

        self.segments = OrderedDict()
        seq = 0
        while seq < self.file_len:
            chunk = self.file_bytes[seq: seq+ MAX_DATA]
            self.segments[seq] = chunk
            seq+=len(chunk)
        
        self.segment[self.file_len] = b'EOF'
        
        self.base = 0
        self.next_seq = 0
        self.unacked_seqs = []
        self.sent_time = {}
        self.retx_count = {}
        self.inflight = 0
        self.dup_ack_count = {}

        self.srtt = None
        self.rrtvar = None
        self.rto = INITIAL_RTO
        
        self.client_addr = None

        self.running = True
    def start(self):
        print("Server is listening:")
        while True:
            readable, _, _ = select.select([self.sock], [], [], 1.0)
            if readable:
                pkt, addr = self.sock.recvfrom(4096)
                self.client_addr = addr
                break
        self.main_loop()

        print("Server is closing")
        self.sock.close()

    def handle_ack(self, ack_next_expected):
        if ack_next_expected <= self.base 
            self.dup_ack_count[ack_next_expected] = self.dup_ack_count.get(ack_next_expected,0) + 1
            if self.dup_ack_count[ack_next_expected] == DUP_ACK_THRESHOLD :
                missing_seq = ack_next_expected
                self.sent_time[missing_seq] = now()
                self.retx_count[missing_seq] = self.retx_count.get(missing_seq, 0) + 1
            return 

        self.dup_ack_count.clear()
        acknowledged_seqs = [s for s in list(self.sent_time.keys() if s < ack_next_expected]
        if acknowledged_seqs :
            sseq = min(acknowledged_seqs)
            sample_rtt = now()- self.sent_time.get(sseq, now())
        
        removed_bytes = 0 
        to_remove = [s for s in self.unacked_seqs if s < ack_next_expected]

        for s in to_remove:
            payload_len = len(self.segments.get(s, b''))
            removed_bytes += payload_len

            try: 
                self.unacked_seqs.remove(s)
            except ValueErroe:
                pass
            if s in self.sent_time:
                del self.sent_time[s]
            if s in self.retx_count:
                del self.retx_count[s]
        
        self.base = ack_next_expected
        self.inflight = max(0, self.inflight - removed_bytes)

        if sample_rtt is not None:
            if self.srtt is None:
                self.srtt = sample_rtt
                self.rttvar = sample_rtt / 2.0
            else:
                self.rttvar = (1 - BETA)*self.rttvar + BETA * abs (self.srtt - sample_rtt)
                self.srtt = (1 - ALPHA)* self.srtt + ALPHA * sample_rtt
            self.rto = max(MIN_RTO, self.srtt + K * self.rttvar)
    

    def _send_segment(self, seq, is_retx= False):
        payload = self.segments.get(seq, b'')
        pkt = make_packet(seq, payload_len)
        try:
            self.sock.sendto(pkt, self.client_addr)
            if is_retx:
                print(f"Its retransmission of seq num {seq}")
            else:
                print(f"Its transmission of seq num {seq}")
        except Exception as e :
            print("WE jhave a exception")
    
    def main_loop(self):
        start_time = now()

        while True:
            if self.base > self.file_len:
                break

            while True :
                if self.next_seq not in self.segments:
                    break
        
                seg_len = len(self.segments[self.next_seq])
                if self.inflight + seg_len > self.sws :
                    break
                self._send_segment(self.next_seq, is_retx= False)
                self.unacked_seqs.append(self.next_seq)
                self.send_time[self.next_seq] = now()
                self.inflight += seg_len

                keys = list(self.segments.keys())
                idx = keys.index(self.next_seq)

                if idx + 1 < len(keys):
                    self.next_seq = keys[idx+1]
                else:
                    break

            readable, _, _ = select.select([self.sock],[],[],0.05)
            if readable:
                pkt, addr = self.sock.recvfrom(4096)
                if addr != self.client_addr
                    continue
                ack_val = parse_ack(pkt)
                if ack_val is not None:
                    self.handle_ack(ack_val)

            if self.unacked_seqs:
                earilest = self.unacked_seqs[0]
                sent_t = self.sent_time.get(earilest,None)
                if sen_t is not None and (now() -  sent_t) > self.rto:
                    print("Timeout")
                    for s in list(self.unacked_seqs):
                        self._send_segment(s, is_retx= True)
                        self.sent_time[s] = now()
                        self.retx_count[s] = self.retx_count.get(s, 0 )+1 
        
        duration = now() - start_time
        print("Done...")
    if __name__ = "__main__" :
        if len(sys.argv) != 4:
            print("Yo")
            sys.exit(1)
        
        sever_ip = sys.argv[1]
        server_port = int(sys.argv[2])
        sws = int(sys.argv[3])
        srv = UDP(sever_ip, server_port,sws)
        srv.start()

        
            


        



