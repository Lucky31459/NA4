import socket
import sys
import os
import time
import select

# Constants
PACKET_SIZE = 1024
TIMEOUT = 0.5  # seconds

def read_file_data(filename):
    """Read file and divide into chunks of PACKET_SIZE."""
    with open(filename, 'rb') as f:
        data = f.read()
    chunks = [data[i:i+PACKET_SIZE] for i in range(0, len(data), PACKET_SIZE)]
    return chunks

def make_packet(seq_num, data):
    """Make a packet: sequence number + data"""
    header = f"{seq_num:06d}".encode()  # 6-digit sequence
    return header + data

def parse_ack(data):
    """Extract ACK number"""
    try:
        return int(data.decode().strip())
    except:
        return None

def main():
    if len(sys.argv) != 4:
        print("Usage: python3 p1_server.py <SERVER_IP> <SERVER_PORT> <SWS>")
        sys.exit(1)

    SERVER_IP = sys.argv[1]
    SERVER_PORT = int(sys.argv[2])
    SWS = int(sys.argv[3])

    # File to send
    FILENAME = "testfile.txt"
    if not os.path.exists(FILENAME):
        with open(FILENAME, "w") as f:
            f.write("This is a test file for UDP transfer reliability check.\n" * 100)

    file_chunks = read_file_data(FILENAME)
    total_packets = len(file_chunks)

    print(f"[SERVER] File '{FILENAME}' has {total_packets} packets to send.")
    print(f"[SERVER] Listening on {SERVER_IP}:{SERVER_PORT} ...")

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((SERVER_IP, SERVER_PORT))
    sock.setblocking(False)  # non-blocking socket

    addr = None
    base = 0
    next_seq = 0
    start_times = [None] * total_packets

    print("[SERVER] Waiting for client request...")

    # Wait for client's initial request
    while True:
        readable, _, _ = select.select([sock], [], [], 1)
        if readable:
            data, addr = sock.recvfrom(1024)
            print(f"[SERVER] Client connected from {addr}")
            break

    # Main loop
    start_time = time.time()
    while base < total_packets:
        # Send packets within window
        while next_seq < base + SWS and next_seq < total_packets:
            pkt = make_packet(next_seq, file_chunks[next_seq])
            sock.sendto(pkt, addr)
            print(f"[SEND] Seq={next_seq}")
            if start_times[next_seq] is None:
                start_times[next_seq] = time.time()
            next_seq += 1

        # Use select to check for ACKs or timeout
        readable, _, _ = select.select([sock], [], [], 0.05)

        if readable:
            data, _ = sock.recvfrom(1024)
            ack = parse_ack(data)
            if ack is not None and ack >= base:
                print(f"[ACK] Received ACK={ack}")
                base = ack + 1
            else:
                print(f"[ACK] Invalid ACK={ack}")

        # Handle timeout (Go-Back-N)
        if base < next_seq:
            elapsed = time.time() - start_times[base]
            if elapsed > TIMEOUT:
                print(f"[TIMEOUT] Resending from Seq={base}")
                for i in range(base, next_seq):
                    pkt = make_packet(i, file_chunks[i])
                    sock.sendto(pkt, addr)
                    start_times[i] = time.time()

    # Send termination signal
    sock.sendto(b"END", addr)
    print("[SERVER] File transfer complete.")
    print(f"[SERVER] Total time = {time.time() - start_time:.2f}s")
    sock.close()

if __name__ == "__main__":
    main()
