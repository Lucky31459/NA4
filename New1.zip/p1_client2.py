#!/usr/bin/env python3
"""
p1_client.py
Usage:
    python3 p1_client.py <SERVER_IP> <SERVER_PORT>

Client sends a 1-byte request to the server (retries up to 5 times, 2s timeout),
then receives packets, sends cumulative ACKs (4-byte next-expected-byte),
reassembles data, and writes received_data.txt.
"""

import socket
import struct
import sys
import time
import select
import os

SEQ_FMT = "!I"
SEQ_SIZE = 4
RESERVED_SIZE = 16
MAX_UDP_PAYLOAD = 1200
MAX_DATA = MAX_UDP_PAYLOAD - SEQ_SIZE - RESERVED_SIZE  # 1180

REQUEST = b'\x01'
REQUEST_RETRIES = 5
REQUEST_TIMEOUT = 2.0
OUTFILE = "received_data.txt"

def parse_data_packet(pkt: bytes):
    """Return (seq:int, data:bytes)"""
    if len(pkt) < SEQ_SIZE + RESERVED_SIZE:
        return None, None
    seq = struct.unpack(SEQ_FMT, pkt[:SEQ_SIZE])[0]
    data = pkt[SEQ_SIZE + RESERVED_SIZE:]
    return seq, data

def make_ack(next_expected: int) -> bytes:
    return struct.pack(SEQ_FMT, next_expected)

def now():
    return time.time()

class P1Client:
    def __init__(self, server_ip, server_port):
        self.server = (server_ip, int(server_port))
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setblocking(False)
        # receive buffer (map seq -> data)
        self.buffer = {}
        self.expected = 0  # next expected byte offset (cumulative ACK value)
        self.eof_received = False
        self.eof_seq = None

    def send_request(self):
        attempts = 0
        while attempts < REQUEST_RETRIES:
            try:
                # send 1-byte request
                self.sock.sendto(REQUEST, self.server)
                # wait for a packet from server
                start = now()
                while now() - start < REQUEST_TIMEOUT:
                    readable, _, _ = select.select([self.sock], [], [], REQUEST_TIMEOUT - (now() - start))
                    if readable:
                        pkt, _ = self.sock.recvfrom(4096)
                        # might be first data packet; process it below
                        seq, data = parse_data_packet(pkt)
                        if seq is not None:
                            self._handle_packet(seq, data)
                            # send ACK after initial packet was processed
                            self._send_ack()
                            return True
                        # else keep waiting
                attempts += 1
                print(f"[CLIENT] Request attempt {attempts} timed out, retrying...")
            except Exception:
                attempts += 1
                print(f"[CLIENT] Request attempt {attempts} exception, retrying...")
        print("[CLIENT] Failed to contact server after retries.")
        return False

    def _send_ack(self):
        ack_pkt = make_ack(self.expected)
        try:
            self.sock.sendto(ack_pkt, self.server)
            # Debug print
            # print(f"[CLIENT] Sent ACK next_expected={self.expected}")
        except Exception:
            pass

    def _handle_packet(self, seq, data):
        # EOF packet special-case
        if data == b'EOF':
            self.eof_received = True
            self.eof_seq = seq
            # Do not store EOF payload
            # We will treat EOF as sentinel; advance expected when appropriate
        else:
            # store if not present
            if seq not in self.buffer:
                self.buffer[seq] = data

        # Try to advance expected (cumulative) as far as possible
        advanced = True
        while advanced:
            advanced = False
            # If the expected offset is present in buffer, consume it
            if self.expected in self.buffer:
                l = len(self.buffer[self.expected])
                self.expected += l
                # optionally write to file incrementally (we'll write at the end)
                advanced = True
            else:
                # If EOF is at expected, advance expected to signal completion
                if self.eof_received and self.eof_seq == self.expected:
                    # treat EOF as consumed and advance expected by 1 to be > file_len
                    self.expected = self.eof_seq + 1
                    advanced = True

    def receive_loop(self):
        start_time = now()
        last_ack_time = 0.0
        # ensure output file cleared
        if os.path.exists(OUTFILE):
            os.remove(OUTFILE)

        # main receive loop
        while True:
            # periodically send ACK even if nothing new (helps server progress)
            if now() - last_ack_time > 0.2:
                self._send_ack()
                last_ack_time = now()

            # termination condition: if EOF received and expected beyond EOF
            if self.eof_received and self.expected > self.eof_seq:
                break

            readable, _, _ = select.select([self.sock], [], [], 0.5)
            if readable:
                pkt, _ = self.sock.recvfrom(4096)
                seq, data = parse_data_packet(pkt)
                if seq is None:
                    continue
                self._handle_packet(seq, data)
                # send ack immediately
                self._send_ack()

        # write reassembled data to file in order
        with open(OUTFILE, "wb") as f:
            seqs = sorted(k for k in self.buffer.keys())
            for s in seqs:
                f.write(self.buffer[s])

        total_time = now() - start_time
        print(f"[CLIENT] Finished. Wrote {OUTFILE}. Time={total_time:.3f}s")

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 p1_client.py <SERVER_IP> <SERVER_PORT>")
        sys.exit(1)
    server_ip = sys.argv[1]
    server_port = int(sys.argv[2])
    client = P1Client(server_ip, server_port)
    ok = client.send_request()
    if not ok:
        sys.exit(1)
    client.receive_loop()

if __name__ == "__main__":
    main()
