import socket
import sys
import time
import select
import struct
from collections import OrderedDict


DUP_ACK_THRESHOLD = 3
ALPHA = 0.125
BETA = 0.25
K = 4
INITIAL_RTO = 1.0
MIN_RTO = 0.1

server_addr = None
sock = None
client_addr = None
send_base = 0
next_seq = 0
window = OrderedDict()
estimated_rtt = None
dev_rtt = 0
rto = INITIAL_RTO
dup_ack_count = 0


def make_packet(seq_num, data):
    header = struct.pack("!I", seq_num)
    return header + data


def parse_ack(packet):
    try:
        ack_num = struct.unpack("!I", packet[:4])[0]
        return ack_num
    except struct.error:
        print("Invalid ACK received")
        return None


def update_rto(sample_rtt):
    global estimated_rtt, dev_rtt, rto
    if estimated_rtt is None:
        estimated_rtt = sample_rtt
    else:
        estimated_rtt = (1 - ALPHA) * estimated_rtt + ALPHA * sample_rtt
        dev_rtt = (1 - BETA) * dev_rtt + BETA * abs(sample_rtt - estimated_rtt)
    rto = max(estimated_rtt + K * dev_rtt, MIN_RTO)


def send_data(data):
    global next_seq
    if not client_addr:
        print("No client connected yet")
        return
    packet = make_packet(next_seq, data)
    sock.sendto(packet, client_addr)
    send_time = time.time()
    window[next_seq] = (packet, send_time)
    print(f"Sent seq={next_seq}")
    next_seq += 1


def handle_ack(ack_num):
    global send_base, dup_ack_count

    if ack_num < send_base:
        return  

    if ack_num in window:
        sample_rtt = time.time() - window[ack_num][1]
        update_rto(sample_rtt)
        del window[ack_num]
        print(f"ACK {ack_num} received, updated RTO={rto:.3f}s")

        while send_base not in window and send_base < next_seq:
            send_base += 1

        dup_ack_count = 0
    else:
   
        dup_ack_count += 1
        print(f"Duplicate ACK {ack_num} count={dup_ack_count}")
        if dup_ack_count >= DUP_ACK_THRESHOLD:
            print(f"Fast retransmit seq={ack_num}")
            retransmit(ack_num)
            dup_ack_count = 0


def retransmit(seq_num):
    if seq_num in window:
        packet, _ = window[seq_num]
        sock.sendto(packet, client_addr)
        window[seq_num] = (packet, time.time())
        print(f"Retransmitted seq={seq_num}")


def check_timeouts():
    current_time = time.time()
    for seq_num, (packet, send_time) in list(window.items()):
        if current_time - send_time > rto:
            print(f"Timeout seq={seq_num}, retransmitting")
            sock.sendto(packet, client_addr)
            window[seq_num] = (packet, current_time)



def run_server(host, port):
    global server_addr, sock, client_addr

    server_addr = (host, port)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(server_addr)
    sock.setblocking(False)

    print(f"Server listening on {server_addr}")

    try:
        while True:
            readable, _, _ = select.select([sock], [], [], 0.1)
            for s in readable:
                data, addr = s.recvfrom(4096)
                if not client_addr:
                    client_addr = addr
                    print(f"Connected to {addr}")

                ack_num = parse_ack(data)
                if ack_num is not None:
                    handle_ack(ack_num)

            check_timeouts()

    except KeyboardInterrupt:
        print("\nServer shutting down.")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        sock.close()



if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python server.py <host> <port>")
        sys.exit(1)

    host = sys.argv[1]
    port = int(sys.argv[2])
    run_server(host, port)