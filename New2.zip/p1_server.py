import socket 
import sys
import time
import select
import struct
from collections import OrderedDict

DUP_ACK_THRESHOLD = 3
ALPHA = 0.125
BETA = 0.25
K = 4
INITIAL_RTO = 1.0
MIN_RTO = 0.1 

def make_packet( seq_num, data):
    header = struct.pack("!I", seq_num) + (b'\x00' * 16)
    return header + data

def parse_ack(pkt):
    return struct.unpack("!I", pkt[:4])[0]

if __name__ == "__main__" :
    server_ip = sys.argv[1]
    server_port = int(sys.argv[2])
    sws = int(sys.argv[3])

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((server_ip, server_port))
    sock.setblocking(False)
    
    with open("data.txt", "rb") as f:
        file_bytes = f.read()

    file_len = len(file_bytes) 
    segments = OrderedDict()
    seq = 0
    while seq < file_len:
        chunk = file_bytes[seq: seq + 1180] 
        segments[seq] = chunk 
        seq+=len(chunk)
        
    segments[file_len] = b'EOF'

    base = 0
    next_seq = 0
    unacked_seqs = []
    sent_time = {}
    inflight = 0
    dup_ack_count = {}

    srtt = None
    rttvar = None
    rto = 1.0
    sample_rtt = None
    client_addr = None

    while True:
        readable, _, _ = select.select([sock], [], [], 1.0)
        if readable:
            pkt, caddr = sock.recvfrom(4096)
            client_addr = caddr
            break
    
    start_time = time.time()

    while True:
            if base >= file_len:
                break

            while True :
                if next_seq not in segments:
                    break
        
                seg_len = len( segments[ next_seq])
                if  len(unacked_seqs) >=  sws :
                    break
                # send_segment( next_seq)
                payload = segments.get(next_seq, b'')
                pkt = make_packet(next_seq, payload)
                sock.sendto(pkt, client_addr)

                unacked_seqs.append( next_seq)
                sent_time[next_seq] =  time.time()
                inflight += seg_len

                next_seq += len(payload)

            readable, _, _ = select.select([ sock],[],[],0.05)
            if readable:
                pkt, addr =  sock.recvfrom(4096)
                if addr !=  client_addr:
                    continue
                ack_val = parse_ack(pkt)
                if ack_val is not None:
                    if ack_val <= base :
                        dup_ack_count[ack_val] = dup_ack_count.get(ack_val,0) + 1
                        if dup_ack_count[ack_val] == DUP_ACK_THRESHOLD :
                            missing_seq = ack_val
                            pkt = make_packet(missing_seq, segments[missing_seq])
                            sock.sendto(pkt, client_addr)
                            sent_time[missing_seq] = time.time()
                        
                    else:
                        dup_ack_count.clear()
                        acknowledged_seqs = [s for s in list(sent_time.keys()) if s < ack_val]
                        
                        if acknowledged_seqs :
                            sseq = min(acknowledged_seqs)
                            sample_rtt =  time.time()- sent_time.get(sseq,  time.time())
                        
                        removed_bytes = 0 
                        to_remove = [s for s in unacked_seqs if s < ack_val]

                        for s in to_remove:
                            payload_len = len(segments.get(s, b''))
                            removed_bytes += payload_len

                            try: 
                                unacked_seqs.remove(s)
                            except ValueError:
                                pass
                            if s in sent_time:
                                del sent_time[s]

                        base = ack_val
                        inflight = max(0, inflight - removed_bytes)

                        if sample_rtt is not None:
                            if srtt is None:
                                srtt = sample_rtt
                                rttvar = sample_rtt / 2.0
                            else:
                                rttvar = (1 - BETA)*rttvar + BETA * abs (srtt - sample_rtt)
                                srtt = (1 - ALPHA)* srtt + ALPHA * sample_rtt
                                rto = max(MIN_RTO, srtt + K * rttvar)

            if  unacked_seqs:
                earliest =  unacked_seqs[0]
                sent_t =  sent_time.get(earliest,None)
                if sent_t is not None and ( time.time() -  sent_t) >  rto:
                    print("Timeout")
                    for s in list( unacked_seqs):
                        # send_segment(s)
                        payload = segments.get(s, b'')
                        pkt = make_packet(s, payload)
                        sock.sendto(pkt, client_addr)
                        sent_time[s] =  time.time()
                        rto *= 2

    pkt = make_packet(file_len, b'EOF')
    sock.sendto(pkt, client_addr)                   
        
    duration =  time.time() - start_time
    print("Done...")