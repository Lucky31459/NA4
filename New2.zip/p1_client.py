import socket
import sys
import struct
import time

def parse_packet(pkt):
    """Extract sequence number and data."""
    seq_num = struct.unpack("!I", pkt[:4])[0]
    data = pkt[20:]  # skip 4 bytes seq + 16 bytes header padding
    return seq_num, data

def make_ack(seq_num):
    """Make ACK packet with just 4-byte sequence number."""
    return struct.pack("!I", seq_num)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python client.py <server_ip> <server_port>")
        sys.exit(1)

    server_ip = sys.argv[1]
    server_port = int(sys.argv[2])

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(2.0)

    # initiate handshake — just send a dummy packet
    sock.sendto(b'HELLO', (server_ip, server_port))

    expected_seq = 0
    received_data = {}
    output_file = open("received_data.txt", "wb")

    print("Client started. Waiting for data...")

    while True:
        try:
            pkt, addr = sock.recvfrom(4096)
        except socket.timeout:
            # timeout waiting for data, might mean end
            continue

        seq_num, data = parse_packet(pkt)

        # Check for EOF
        if data == b'EOF':
            print("Received EOF, sending final ACK and exiting.")
            ack_pkt = make_ack(seq_num + len(data))
            sock.sendto(ack_pkt, addr)
            break

        # In-order delivery
        if seq_num == expected_seq:
            output_file.write(data)
            expected_seq += len(data)

            # Deliver buffered out-of-order segments (if any)
            while expected_seq in received_data:
                output_file.write(received_data.pop(expected_seq))
                expected_seq += len(data)

        # Out-of-order (store it)
        elif seq_num > expected_seq:
            received_data[seq_num] = data

        # Always send cumulative ACK (like TCP)
        ack_pkt = make_ack(expected_seq)
        sock.sendto(ack_pkt, addr)

    output_file.close()
    sock.close()
    print("File received successfully and saved as 'received_data.txt'.")
